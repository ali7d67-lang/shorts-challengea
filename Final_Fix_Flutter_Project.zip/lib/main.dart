import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Shorts Challenge',
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(
          child: Text('Shorts Challenge App Ready!'),
        ),
      ),
    );
  }
}
